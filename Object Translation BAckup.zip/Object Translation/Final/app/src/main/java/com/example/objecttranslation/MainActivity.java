package com.example.objecttranslation;

import android.app.Activity;
import android.content.Intent;

import android.content.pm.PackageManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
//import android.support.v7.app.AppCompatActivity;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
//package com.google.firebase.codelab.mlkit;


public class MainActivity extends AppCompatActivity
{
    private static final int pic_id = 01;

    Button camera_open_id;
    ImageView click_image_id;

    @Override
    protected void onCreate(Bundle savedInstancdState)
    {
        super.onCreate(savedInstancdState);
        setContentView(R.layout.activity_main);

        camera_open_id = (Button) findViewById(R.id.camera_button);
        click_image_id = (ImageView) findViewById(R.id.click_image);
        camera_open_id.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Create the camera_intent ACTION_IMAGE_CAPTURE
                // it will open the camera for capture the image
                Intent camera_intent
                        = new Intent(MediaStore
                        .ACTION_IMAGE_CAPTURE);

                // Start the activity with camera_intent,
                // and request pic id
                startActivityForResult(camera_intent, pic_id);
            }
        });
    }
        protected void onActivityResult(int requestCode, int resultCode, Intent data)
        {
            super.onActivityResult(requestCode, resultCode, data);
            // Match the request 'pic id with requestCode
            if (requestCode == pic_id)
            {

                // BitMap is data structure of image file
                // which stor the image in memory
                Bitmap photo = (Bitmap)data.getExtras()
                        .get("data");

                // Set the image in imageview for display
                click_image_id.setImageBitmap(photo);
            }
        }

    static final int REQUEST_IMAGE_CAPTURE = 1;
    private void dispatchTakePictureIntent()
    {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null)
        {
            startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
        }
    }
}

