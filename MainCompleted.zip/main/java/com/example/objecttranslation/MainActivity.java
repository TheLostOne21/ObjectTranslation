package com.example.objecttranslation;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.content.Context;

import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.lang.Object;
import android.content.pm.PackageManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
//import android.support.v7.app.AppCompatActivity;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.objects.FirebaseVisionObject;
import com.google.firebase.ml.vision.objects.FirebaseVisionObjectDetector;
//package com.google.firebase.codelab.mlkit;


public class MainActivity extends AppCompatActivity
{
    private static final int pic_id = 01;

    Button camera_open_id;
    ImageView click_image_id;


    @Override
    protected void onCreate(Bundle savedInstancdState)
    {
        super.onCreate(savedInstancdState);
        setContentView(R.layout.activity_main);

        camera_open_id = (Button) findViewById(R.id.camera_button);
        click_image_id = (ImageView) findViewById(R.id.click_image);
        camera_open_id.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Create the camera_intent ACTION_IMAGE_CAPTURE
                // it will open the camera for capture the image
                Intent camera_intent
                        = new Intent(MediaStore
                        .ACTION_IMAGE_CAPTURE);

                // Start the activity with camera_intent,
                // and request pic id
                startActivityForResult(camera_intent, pic_id);
            }
        });
    }
        protected void onActivityResult(int requestCode, int resultCode, Intent data)
        {
            super.onActivityResult(requestCode, resultCode, data);
            // Match the request 'pic id with requestCode
            if (requestCode == pic_id)
            {

                Bitmap photo = (Bitmap)data.getExtras()
                        .get("data");

                click_image_id.setImageBitmap(photo);


                //begin firebase
                FirebaseVisionImage FBImage = FirebaseVisionImage.fromBitmap(photo);

                Uri.Builder Href = new Uri.Builder();

                Href.path("C:/Users/Josh/Pictures/bicycle.jpg");
                //For firebase image proccessing from a saved image on phone
                try {
                    FBImage = FirebaseVisionImage.fromFilePath(getBaseContext(), Href.build());
                } catch (IOException e) {
                    e.printStackTrace();
                }

                FirebaseVisionObjectDetector objectDetector = FirebaseVision.getInstance().getOnDeviceObjectDetector();

                Task<List<FirebaseVisionObject>> task = objectDetector.processImage(FBImage);//.onSuccessTask();
                String query;
                String TranslatedQuery;
                for(FirebaseVisionObject e: task.getResult())
                {
                    //need to add a text for this to work
                    query = e.getEntityId();
                    //Translation translation = translate.translate(query, Translate.TranslateOption.targetLanguage("tr"), Translate.TranslateOption.model("base"));
                    // TranslatedQuery = translation.getTranslatedText();

                    //translatedTv.setText(translatedText);
                }
            }
        }

    static final int REQUEST_IMAGE_CAPTURE = 1;
    private void dispatchTakePictureIntent() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
        }
    }
}

